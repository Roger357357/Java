package senac.poo.ado7;

public class Primeiroobjeto<T> {

	public Primeiroobjeto() {
	}
}
