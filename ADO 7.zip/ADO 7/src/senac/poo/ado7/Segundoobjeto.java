package senac.poo.ado7;

public class Segundoobjeto<T> {

	public Segundoobjeto() {
		
	}
}
