package senac.poo.ado6;

public interface Prioridade {

	public boolean autentica();
	public void imprime();
}
